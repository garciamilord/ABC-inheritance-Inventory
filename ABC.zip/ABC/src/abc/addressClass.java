/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abc;

/**
 *
 * @author garci
 */
public class addressClass  {
   
       
       private String state;

   // parameterized constructor
   public addressClass( String State)
   {
     
       state = State;
      
   }
 
   // to get the state name
   public String getState()
   {
       return state;
   }

}

    
 
    

